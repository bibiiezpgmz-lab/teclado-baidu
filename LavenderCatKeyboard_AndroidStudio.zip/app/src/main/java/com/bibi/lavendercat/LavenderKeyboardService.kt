package com.bibi.lavendercat

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.Button
import android.widget.TextView
import android.widget.ImageView

class LavenderKeyboardService : InputMethodService() {
    private var shift = false
    private var symbols = false

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 4, 4, 4)
            val bitmap = BitmapFactory.decodeResource(resources, R.drawable.keyboard_bg)
            background = BitmapDrawable(resources, bitmap).apply { alpha = 115 }
        }
        val suggestions = TextView(this).apply {
            text = "  ✦  ♡  ฅ^•ﻌ•^ฅ  ♡  ✦"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(91, 48, 135))
            setPadding(2, 4, 2, 6)
        }
        root.addView(suggestions, LinearLayout.LayoutParams(-1, 34))
        val rows = if (!symbols) listOf(
            listOf("q","w","e","r","t","y","u","i","o","p"),
            listOf("a","s","d","f","g","h","j","k","l","ñ"),
            listOf("⇧","z","x","c","v","b","n","m","⌫"),
            listOf("?123",",","😊","ESPAÑOL",".","↵")
        ) else listOf(
            listOf("1","2","3","4","5","6","7","8","9","0"),
            listOf("@","#","$","%","&","-","+","(",")","/"),
            listOf("= ","*","\"","' ",":",";","!","⌫"),
            listOf("ABC",",","😊","ESPAÑOL",".","↵")
        )
        rows.forEachIndexed { index, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { label ->
                val btn = Button(this).apply {
                    text = label
                    textSize = if (label == "ESPAÑOL") 10f else 16f
                    isAllCaps = false
                    setTextColor(Color.rgb(76, 45, 105))
                    background = GradientDrawable().apply {
                        setColor(Color.argb(220, 255, 252, 255))
                        setStroke(2, Color.rgb(190, 160, 222))
                        cornerRadius = 18f
                    }
                    setPadding(0, 0, 0, 0)
                    setOnClickListener { handleKey(label) }
                }
                val weight = if (label == "ESPAÑOL" || label == "?123" || label == "ABC" || label == "↵" || label == "⌫" || label == "⇧") 1.35f else 1f
                val lp = LinearLayout.LayoutParams(0, if (index == 3) 48 else 48, weight)
                lp.setMargins(2, 2, 2, 2)
                line.addView(btn, lp)
            }
            root.addView(line)
        }
        return root
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "↵" -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_UNSPECIFIED
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_SEARCH || action == EditorInfo.IME_ACTION_SEND || action == EditorInfo.IME_ACTION_NEXT) ic.performEditorAction(action)
                else ic.commitText("\n", 1)
            }
            "⇧" -> { shift = !shift; setInputView(onCreateInputView()) }
            "?123" -> { symbols = true; setInputView(onCreateInputView()) }
            "ABC" -> { symbols = false; setInputView(onCreateInputView()) }
            "ESPAÑOL" -> ic.commitText(" ", 1)
            "😊" -> ic.commitText("😊", 1)
            "," -> ic.commitText(",", 1)
            "." -> ic.commitText(".", 1)
            else -> ic.commitText(if (shift) key.uppercase() else key, 1)
        }
        if (shift && key.length == 1) shift = false
    }
}
