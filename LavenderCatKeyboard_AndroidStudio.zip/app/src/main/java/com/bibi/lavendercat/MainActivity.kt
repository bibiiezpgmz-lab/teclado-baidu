package com.bibi.lavendercat

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(249, 243, 255))
        }
        val title = TextView(this).apply {
            text = "🐱 Lavender Cat Keyboard 💜"
            textSize = 24f
            setTextColor(Color.rgb(91, 48, 135))
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Teclado en español con diseño lavanda. Actívalo en los ajustes de Android y después selecciónalo como teclado."
            textSize = 16f
            setTextColor(Color.rgb(80, 65, 95))
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        }
        val enable = Button(this).apply {
            text = "1. Activar teclado"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        val choose = Button(this).apply {
            text = "2. Elegir teclado"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(enable)
        root.addView(choose)
        setContentView(root)
    }
}
