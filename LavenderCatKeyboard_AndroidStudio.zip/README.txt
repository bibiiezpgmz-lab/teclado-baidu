LAVENDER CAT KEYBOARD — proyecto Android

Incluye un teclado IME básico para Android, distribución español latinoamericano (incluye ñ), teclas de números/símbolos y el fondo kawaii lavanda creado en esta conversación.

IMPORTANTE:
- Este ZIP contiene el código fuente de Android Studio, no un APK ya compilado.
- Para crear el APK: abre la carpeta en Android Studio, deja que Gradle sincronice y elige Build > Build APK(s).
- Instala el APK en tu teléfono. Android puede pedir autorización para instalar apps desconocidas.
- Abre la app y toca “Activar teclado”; habilítalo en Ajustes. Luego toca “Elegir teclado” y selecciona Lavender Cat Keyboard.
- Como cualquier teclado de terceros, lo que escribas puede incluir información sensible. Este proyecto no incluye permisos de internet ni envía texto a ningún servidor.
- Versión inicial: teclado básico, sin autocorrección ni predicción inteligente.
